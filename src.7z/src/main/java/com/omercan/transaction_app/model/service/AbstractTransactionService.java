package com.omercan.transaction_app.model.service;

import com.omercan.transaction_app.model.entity.Transaction;
import com.omercan.transaction_app.model.repository.TransactionRepository;

import java.util.List;

public abstract class AbstractTransactionService implements EntityService<Transaction,Integer>
{

    protected final TransactionRepository transactionRepository;


    public AbstractTransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public abstract List<Transaction> findAllByOrderByTransactionTimeDesc();

    public abstract List<Transaction> findByUserIdEquals(Integer userId);
}
