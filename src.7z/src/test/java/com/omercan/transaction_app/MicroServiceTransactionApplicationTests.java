package com.omercan.transaction_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceTransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
